import 'package:flutter_test/flutter_test.dart';
import 'package:app_form/main.dart';

void main() {
  testWidgets('Muestra la pantalla de login', (tester) async {
    await tester.pumpWidget(const MyApp());
    await tester.pumpAndSettle();
    expect(find.text('Bienvenido'), findsOneWidget);
  });
}

// Mapa (key y value) con los usuarios. La key es el correo.
const Map<String, Map<String, String>> users = {
  'yajairaroodriguez123@gmail.com': {
    'name': 'Yajaira Rodríguez',
    'password': '123456',
    'phone': '3145926100',
    'email': 'yajairaroodriguez123@gmail.com',
    'profession': 'Desarrolladora de software',
    'image': 'assets/images/yajaira.jpg',
  },
  'brendaisabel.gaviriatorres@unitecnar.edu.com': {
    'name': 'Brenda Gaviria',
    'password': '1234567',
    'phone': '3001112233',
    'email': 'brendaisabel.gaviriatorres@unitecnar.edu.com',
    'profession': 'Ingeniera de sistemas',
    'image': 'assets/images/brendaisabel.jpg',
  },
  'harleyquinn@correo.com': {
    'name': 'Harley Quinn',
    'password': '12345678',
    'phone': '3109998877',
    'email': 'harleyquinn@correo.com',
    'profession': 'Diseñadora gráfica',
    'image': 'assets/images/harley.png',
  },
};

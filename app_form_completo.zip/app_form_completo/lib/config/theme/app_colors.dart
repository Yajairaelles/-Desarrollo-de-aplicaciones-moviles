import 'package:flutter/material.dart';

class AppColors {
  static const violet = Color(0xFF7C3AED);
  static const deepViolet = Color(0xFF4C1D95);
  static const pink = Color(0xFFEC4899);
  static const background = Color(0xFFF7F3FF);
  static const textDark = Color(0xFF2E1065);

  static const gradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [deepViolet, violet, pink],
  );
}

import 'package:go_router/go_router.dart';
import '../../presentation/screen/dashboard/dashboard_screen.dart';
import '../../presentation/screen/login/login_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/login',
  routes: [
    GoRoute(
      path: '/login',
      name: 'login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/dashboard',
      name: 'dashboard',
      // Si alguien entra al dashboard sin autenticarse, vuelve al login.
      redirect: (context, state) => state.extra == null ? '/login' : null,
      builder: (context, state) {
        final user = state.extra as Map<String, String>;
        return DashboardScreen(user: user);
      },
    ),
  ],
);

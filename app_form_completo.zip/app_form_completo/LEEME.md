# app_form - como instalar

Copia y reemplaza, DENTRO de la carpeta de tu proyecto (la que tiene android, ios, lib):
  - pubspec.yaml
  - analysis_options.yaml
  - lib/
  - assets/
  - test/

Luego, en la terminal (parado en esa carpeta):
  flutter pub get
  flutter run

Usuarios:
  yajairaroodriguez123@gmail.com / 123456
  carlos@correo.com / carlos2026
  maria@correo.com / maria2026
